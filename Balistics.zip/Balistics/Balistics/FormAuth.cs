﻿using Balistics.LogicClass;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Balistics
{
    public partial class FormAuth : Form
    {
        //Объекты типов таблиц БД
        SharovBallisticsDataSet.UserLoginDataTable dataUsers;
        //Данные всей таблицы истории
        SharovBallisticsDataSet.LogHistoryDataTable dataLoginHistory;


        // Отображение формы авторизации
        public FormAuth()
        {
            InitializeComponent();
        }

        //Счетчик неудачных входов
        int UnsecLoginCount = 0;

        private void FormAuth_Load(object sender, EventArgs e)
        {
            //В начале каждого запуска приложения удалять все предыдущие данные в истории
            //Получить все данные из таблицы История входа
            dataLoginHistory = logHistoryTableAdapter.GetData();
            //Получение всех записей из таблицы Users
            dataUsers = this.userLoginTableAdapter.GetData();
            //Количество записей
            int totalCount = dataUsers.Count;

            this.checkBoxShowPass.Checked = false;
            textBoxPass.UseSystemPasswordChar = true;  //Пароль не видим


        }

        //Авторизация
        private void buttonEnter_Click(object sender, EventArgs e)
        {

            string log, pas;
            pas = this.textBoxPass.Text;
            log = this.textBoxLogin.Text;			//Исходные данные
            dataUsers = this.userLoginTableAdapter.GetData();

            DateTime dt = DateTime.Now;			//Дата для истории

            //Наложить на все записи фильтр на совпадение по логину и паролю
            var filter = dataUsers.Where(rec => rec.Email == log && rec.Password == pas);
            if (filter.Count() == 0)    //Нет записей – совпадение логина+пароля не найдено
            {
                MessageBox.Show("Таких данных нет.");

                //Санкции при неверном вводе данных
                UnsecLoginCount++;
                if (UnsecLoginCount == 1)
                    Thread.Sleep(1000);
                if (UnsecLoginCount == 2)
                    Thread.Sleep(5000);
                if (UnsecLoginCount == 3)
                    this.Close();
                try
                {
                    //Добавить в таблицу истории запись с неудачным входом
                    logHistoryTableAdapter.Insert(log, dt, false);
                }
                catch
                {
                    MessageBox.Show("Ошибка в истории входа");
                }

            }
            else				//Данные в БД есть
            {
                try
                {
                    //Добавить в таблицу истории запись с удачным входом
                    logHistoryTableAdapter.Insert(log, dt, true);
                }
                catch
                {
                    MessageBox.Show("Ошибка в истории входа");
                }

                //Получение данных об этом пользователе и запись их в общий класс
                //Первая и единственная запись с 0 индексом
                ClassTotal.idUser = filter.ElementAt(0).id;
                ClassTotal.idRole = filter.ElementAt(0).IdRole;
                ClassTotal.login = filter.ElementAt(0).Email;
                //Переход к формам в зависимости от роли
                switch (ClassTotal.idRole)
                {
                    case 3:
                        try
                        {
                            MessageBox.Show("Вы успешно авторизовались как ученик.");
                            FormStudent fs = new FormStudent();
                            this.Hide();
                            fs.ShowDialog();
                            this.Show();
                        }
                        catch { }
                        break;
                    case 2:
                        try
                        {
                            MessageBox.Show("Вы успешно авторизовались как преподаватель.");
                            FormTeacher ft = new FormTeacher();
                            this.Hide();
                            ft.ShowDialog();
                            this.Show();
                        }
                        catch { }
                        break;
                    case 1:
                        try
                        {
                            MessageBox.Show("Вы успешно авторизовались как администратор.");
                            FormAdmin fo = new FormAdmin();
                            this.Hide();
                            fo.ShowDialog();
                            this.Show();
                        }
                        catch { }
                        break;
                }
            }
        }


        //Отображение пароля
        private void checkBoxShowPass_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBoxShowPass.Checked)
                textBoxPass.UseSystemPasswordChar = false;
            else
                textBoxPass.UseSystemPasswordChar = true;
        }

        //Закрыть
        private void buttonExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        //Тоже закрыть, но крестиком
        private void FormAuth_FormClosing(object sender, FormClosingEventArgs e)
        {

            Application.Exit();
        }



    }
}
