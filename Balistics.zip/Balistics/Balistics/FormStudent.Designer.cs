﻿namespace Balistics
{
    partial class FormStudent
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonRegistration = new System.Windows.Forms.Button();
            this.buttonMySponsors = new System.Windows.Forms.Button();
            this.buttonWorkWithProfile = new System.Windows.Forms.Button();
            this.buttonBack = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();



            this.studentTableAdapter = new Balistics.SharovBallisticsDataSetTableAdapters.StudentTableAdapter();


            this.SuspendLayout();
            // 
            // buttonRegistration
            // 
            this.buttonRegistration.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonRegistration.Location = new System.Drawing.Point(47, 220);
            this.buttonRegistration.Name = "buttonRegistration";
            this.buttonRegistration.Size = new System.Drawing.Size(248, 47);
            this.buttonRegistration.TabIndex = 9;
            this.buttonRegistration.Text = "Свободный режим";
            this.buttonRegistration.UseCompatibleTextRendering = true;
            this.buttonRegistration.UseVisualStyleBackColor = true;
            this.buttonRegistration.Click += new System.EventHandler(this.buttonRegistration_Click);
            // 
            // buttonMySponsors
            // 
            this.buttonMySponsors.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonMySponsors.Location = new System.Drawing.Point(47, 163);
            this.buttonMySponsors.Name = "buttonMySponsors";
            this.buttonMySponsors.Size = new System.Drawing.Size(248, 47);
            this.buttonMySponsors.TabIndex = 8;
            this.buttonMySponsors.Text = "Лабораторная работа";
            this.buttonMySponsors.UseCompatibleTextRendering = true;
            this.buttonMySponsors.UseVisualStyleBackColor = true;
            this.buttonMySponsors.Click += new System.EventHandler(this.buttonMySponsors_Click);
            // 
            // buttonWorkWithProfile
            // 
            this.buttonWorkWithProfile.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonWorkWithProfile.Location = new System.Drawing.Point(47, 110);
            this.buttonWorkWithProfile.Name = "buttonWorkWithProfile";
            this.buttonWorkWithProfile.Size = new System.Drawing.Size(248, 47);
            this.buttonWorkWithProfile.TabIndex = 7;
            this.buttonWorkWithProfile.Text = "Работа с профилем";
            this.buttonWorkWithProfile.UseCompatibleTextRendering = true;
            this.buttonWorkWithProfile.UseVisualStyleBackColor = true;
            this.buttonWorkWithProfile.Click += new System.EventHandler(this.buttonWorkWithProfile_Click);
            // 
            // buttonBack
            // 
            this.buttonBack.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonBack.Location = new System.Drawing.Point(47, 273);
            this.buttonBack.Name = "buttonBack";
            this.buttonBack.Size = new System.Drawing.Size(248, 47);
            this.buttonBack.TabIndex = 6;
            this.buttonBack.Text = "Назад";
            this.buttonBack.UseCompatibleTextRendering = true;
            this.buttonBack.UseVisualStyleBackColor = true;
            this.buttonBack.Click += new System.EventHandler(this.buttonBack_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Comic Sans MS", 15.75F, System.Drawing.FontStyle.Bold);
            this.label1.Location = new System.Drawing.Point(132, 65);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(85, 30);
            this.label1.TabIndex = 5;
            this.label1.Text = "Ученик";
            // 
            // FormStudent
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(343, 385);
            this.Controls.Add(this.buttonRegistration);
            this.Controls.Add(this.buttonMySponsors);
            this.Controls.Add(this.buttonWorkWithProfile);
            this.Controls.Add(this.buttonBack);
            this.Controls.Add(this.label1);
            this.Name = "FormStudent";
            this.Text = "FormStudent";
            this.Load += new System.EventHandler(this.FormStudent_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonRegistration;
        private System.Windows.Forms.Button buttonMySponsors;
        private System.Windows.Forms.Button buttonWorkWithProfile;
        private System.Windows.Forms.Button buttonBack;
        private System.Windows.Forms.Label label1;
        private SharovBallisticsDataSetTableAdapters.StudentTableAdapter studentTableAdapter;
        //this.userLoginTableAdapter = new Balistics.SharovBallisticsDataSetTableAdapters.UserLoginTableAdapter();
        //this.logHistoryTableAdapter = new Balistics.SharovBallisticsDataSetTableAdapters.LogHistoryTableAdapter();
    }
}