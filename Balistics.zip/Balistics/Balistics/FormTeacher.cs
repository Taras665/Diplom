﻿using Balistics.LogicClass;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Balistics
{
    public partial class FormTeacher : Form
    {
        SharovBallisticsDataSet.TeacherDataTable dataTeachers;
        SharovBallisticsDataSet.TeacherRow rowTeacher;

        public FormTeacher()
        {
            InitializeComponent();
        }

        private void buttonCheckLab_Click(object sender, EventArgs e)
        {
            FormCheckLab fcl = new FormCheckLab();
            this.Hide();
            fcl.ShowDialog();
            this.Show();
        }

        /// <summary>
        /// Переход на форму с профилем для просмотра и редактирования
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void buttonWorkWithProfile_Click(object sender, EventArgs e)
        {
            //Конструктору передается команда для просмотра или редактирования формы
            FormWorkWithTeacherProfile fsp = new FormWorkWithTeacherProfile("ViewEdit");
            this.Hide();
            fsp.ShowDialog();
            this.Show();
        }

        private void buttonBack_Click(object sender, EventArgs e)
        {
            FormAuth fsr = new FormAuth();
            this.Hide();
            fsr.ShowDialog();
            this.Show();
        }


        private void FormSponsor_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        /// <summary>
        /// При загрузке формы проверить заполнение профиля этого спонсора
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void FormTeacher_Load(object sender, EventArgs e)
        {
            //Получили все данные
            dataTeachers = this.teacherTableAdapter.GetData();
            //Ищем профиль того аккаунта, который вошел в систему
            rowTeacher = dataTeachers.FindByidTeacher(ClassTotal.idUser);
            if (rowTeacher == null)
            {
                MessageBox.Show("У Вас не заполнен профиль."
                    + Environment.NewLine + "Надо его заполнить для дальнейшей работы");
                //Конструктору передается команда о добавлении
                FormWorkWithTeacherProfile fsp = new FormWorkWithTeacherProfile("Addition");
                this.Hide();
                fsp.ShowDialog();
                this.Show();
            }
            else
            {
                MessageBox.Show("У Вас заполнен профиль."
                                    + Environment.NewLine + "Можете работат в системе");
            }
        }

        private void buttonCreateLab_Click(object sender, EventArgs e)
        {

        }
    }
}
