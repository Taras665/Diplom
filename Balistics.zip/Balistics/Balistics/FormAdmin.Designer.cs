﻿namespace Balistics
{
    partial class FormAdmin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonWorkWithAccoounts = new System.Windows.Forms.Button();
            this.buttonBack = new System.Windows.Forms.Button();
            this.buttonLoginHistory = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // buttonWorkWithAccoounts
            // 
            this.buttonWorkWithAccoounts.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.buttonWorkWithAccoounts.Location = new System.Drawing.Point(51, 72);
            this.buttonWorkWithAccoounts.Name = "buttonWorkWithAccoounts";
            this.buttonWorkWithAccoounts.Size = new System.Drawing.Size(248, 47);
            this.buttonWorkWithAccoounts.TabIndex = 8;
            this.buttonWorkWithAccoounts.Text = "Управление пользователями";
            this.buttonWorkWithAccoounts.UseVisualStyleBackColor = true;
            this.buttonWorkWithAccoounts.Click += new System.EventHandler(this.buttonWorkWithAccoounts_Click);
            // 
            // buttonBack
            // 
            this.buttonBack.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.buttonBack.Location = new System.Drawing.Point(51, 178);
            this.buttonBack.Name = "buttonBack";
            this.buttonBack.Size = new System.Drawing.Size(248, 47);
            this.buttonBack.TabIndex = 7;
            this.buttonBack.Text = "Назад";
            this.buttonBack.UseVisualStyleBackColor = true;
            this.buttonBack.Click += new System.EventHandler(this.buttonBack_Click);
            // 
            // buttonLoginHistory
            // 
            this.buttonLoginHistory.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.buttonLoginHistory.Location = new System.Drawing.Point(51, 125);
            this.buttonLoginHistory.Name = "buttonLoginHistory";
            this.buttonLoginHistory.Size = new System.Drawing.Size(248, 47);
            this.buttonLoginHistory.TabIndex = 6;
            this.buttonLoginHistory.Text = "История входов";
            this.buttonLoginHistory.UseVisualStyleBackColor = true;
            this.buttonLoginHistory.Click += new System.EventHandler(this.buttonLoginHistory_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(9, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(336, 31);
            this.label1.TabIndex = 5;
            this.label1.Text = "Форма администратора";
            // 
            // FormAdmin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(355, 270);
            this.Controls.Add(this.buttonWorkWithAccoounts);
            this.Controls.Add(this.buttonBack);
            this.Controls.Add(this.buttonLoginHistory);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "FormAdmin";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FormAdmin_FormClosing);
            this.Load += new System.EventHandler(this.FormAdmin_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button buttonWorkWithAccoounts;
        private System.Windows.Forms.Button buttonBack;
        private System.Windows.Forms.Button buttonLoginHistory;
        private System.Windows.Forms.Label label1;
    }
}