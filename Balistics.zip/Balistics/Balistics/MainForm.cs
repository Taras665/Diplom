﻿using Balistics.LogicClass;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Balistics
{
    public partial class MainForm : Form
    {
        SharovBallisticsDataSet.StudentDataTable dataStudent;   //Все записи
        SharovBallisticsDataSet.StudentRow rowStudent;       //Отдельная строка
        SharovBallisticsDataSet.LabWorkDataTable dataLabWork;   //Все записи
        SharovBallisticsDataSet.LabWorkRow rowLabWork;       //Отдельная строка
        SharovBallisticsDataSet.LabWorkStudentDataTable dataLabWorkStudent;   //Все записи
        SharovBallisticsDataSet.LabWorkStudentRow rowLabWorkStudent;		//Отдельная строка


        PointXY point = new PointXY();
        Presets presets = new Presets();
        int labVar = 0;
        public MainForm(bool labEnable, int labVarImport = 0)
        {
            InitializeComponent();
            for (int i = 0; i < Presets.Preset.Length; i++)
            {
                comboBoxchose.Items.Add(Presets.Preset[i].name);
            }
            comboBoxchose.SelectionStart = comboBoxchose.SelectedIndex = 0;
            numUpDownAngle.Minimum = 0;
            numUpDownAngle.Maximum = 360;
            labVar = labVarImport; 
            if (labEnable)
            { 
                tabPage3.Parent = tabControl1;
                dataLabWork = this.labWorkTableAdapter.GetData();
                rowLabWork = dataLabWork.FindByid(labVar);
                labelMaxL.Text = "1) Найти максимальную длину/высоту и время \r\nпод углом " + rowLabWork.correctAngleValue + " градусов (" + rowLabWork.nameGun + ")";
                labelCorrectAngle.Text = "3) Под каким углом снаряд попадёт в цель\r\n с расстояния " + rowLabWork.correctTargetValue + " м.";
            }
            else 
            { 
                tabPage3.Parent = null; 
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            labelmax.Text = "";
            labelmax.Update();
            labeldest.Text = "Ожидание...";
            labeldest.ForeColor = Color.Black;
            labeldest.Update();

            if (tbHeight.Text == "" || tbLength.Text == "" || tbSpeed.Text == ""
                || tbDamageRadius.Text == "" || tbTarget.Text == "")    MessageBox.Show("Введите все данные!");
            else
            {
                chart1.Series[0].Points.Clear();
                chart1.Series[1].Points.Clear();
                chart1.Series[2].Points.Clear();
                chart1.Series[3].Points.Clear();
                chart1.Series[4].Points.Clear();
                chart1.Series[2].Color = Color.Orange;
                chart1.Series[3].Color = Color.Black;


                Double lenght = Double.Parse(tbLength.Text),
                    height = Double.Parse(tbHeight.Text),
                    degreeAngle = Double.Parse(numUpDownAngle.Value.ToString()),
                    speed = Double.Parse(tbSpeed.Text),
                    target = Double.Parse(tbTarget.Text),
                    damage = Double.Parse(tbDamageRadius.Text);

                if (radioButtonAR.Checked)
                {
                    Double diametrBullet = Double.Parse(tbDiametr.Text),
                        CRF = Double.Parse(tbCRF.Text),
                        weightBullet = Double.Parse(tbWeight.Text);
                    Program.logic.Update(lenght, height, degreeAngle, speed, target, damage, true, diametrBullet, CRF, weightBullet);
                }
                else Program.logic.Update(lenght, height, degreeAngle, speed, target, damage, false);
                chart1.Series[2].Points.AddXY(Program.logic.target, 0);
                point.y = Program.logic.y;
                while (point.y >= 0)
                {
                    chart1.Series[3].Points.Clear();
                    point = Program.logic.AddPoint();
                    chart1.Series[0].Points.AddXY(point.x, point.y);
                    chart1.Series[1].Points.AddXY(point.x, 0);
                    chart1.Series[3].Points.AddXY(point.x, point.y);
                    chart1.Update();
                }
                dataGridView1.DataSource = Program.export.booksTable;
                dataGridView1.Update();

                for (double k = -Program.logic.damage; k <= Program.logic.damage; k += Program.logic.time)
                {
                    chart1.Series[4].Points.AddXY(point.x + k, Math.Sqrt(Math.Pow(damage, 2) - Math.Pow(k, 2)));
                    chart1.Series[4].Points.AddXY(point.x + k, -Math.Sqrt(Math.Pow(damage, 2) - Math.Pow(k, 2)));
                }
                Result result = Program.logic.GetResult();
                labeldest.Text = result.textResult;
                labeldest.ForeColor = result.color;
                chart1.Series[2].Color = result.color;
            }

        }

        private void comboBoxchose_SelectedIndexChanged(object sender, EventArgs e)
        {
            int id = presets.GetID(comboBoxchose.Text);
            tbLength.Text = Presets.Preset[id].lenght;
            tbHeight.Text = Presets.Preset[id].height;
            numUpDownAngle.Maximum = Decimal.Parse(Presets.Preset[id].maxDegreeAngle);
            tbSpeed.Text = Presets.Preset[id].speedBulletInitial;
            tbDamageRadius.Text = Presets.Preset[id].damage;
            tbTarget.Text = Presets.Preset[id].target;
            tbCRF.Text = Presets.Preset[id].CRF;
            tbDiametr.Text = Presets.Preset[id].diametrBullet;
            tbWeight.Text = Presets.Preset[id].weightBullet;

            if (comboBoxchose.SelectedIndex == 0)
            {
                tbLength.Enabled = true;
                tbHeight.Enabled = true;
                tbDiametr.Enabled = true;
                tbWeight.Enabled = true;
                tbSpeed.Enabled = true;
                tbCRF.Enabled = true;
                tbDamageRadius.Enabled = true;
                numUpDownAngle.Maximum = 180;
            }
            else
            {
                tbLength.Enabled = false;
                tbHeight.Enabled = false;
                tbDiametr.Enabled = false;
                tbWeight.Enabled = false;
                tbSpeed.Enabled = false;
                tbCRF.Enabled = false;
                tbDamageRadius.Enabled = false;
            }
        }
        private void tB_KeyPress(object sender, KeyPressEventArgs e)
        {
            char check = e.KeyChar;
            if (!Char.IsDigit(check) && (check != 8) && (check != 44))
            {
                e.Handled = true;
            }

            if (e.KeyChar == ',')
            {
                if ((sender as TextBox).Text.Length == 0)
                    if (e.KeyChar == ',') e.Handled = true;
                if ((sender as TextBox).Text.IndexOf(',') != -1)
                    e.Handled = true;
                return;
            }
            if (e.KeyChar == '0')
            {
                if ((sender as TextBox).Text == "0")
                    if (e.KeyChar == '0') e.Handled = true;
                if ((sender as TextBox).Text.IndexOf(',') != -1)
                    e.Handled = false;

            }
        }

        private void radioButton_CheckedChanged(object sender, EventArgs e)
        {
            panelAR.Enabled = radioButtonAR.Checked;
        }

        private void buttonExport_Click(object sender, EventArgs e)
        {
            string ms = Program.export.CreateFile();
            MessageBox.Show(ms);
        }

        private void MainForm_Load(object sender, EventArgs e)
        {

        }

        private void buttonLab_Click(object sender, EventArgs e)
        {
            dataLabWorkStudent = labWorkStudentTableAdapter.GetData();
            bool MaxLenght = false;
            bool MaxHeight = false;
            bool correct1 = false;
            bool correct2 = false;
            bool correct3 = false;
            bool correctAngle = false;
            if (tbMaxLenght.Text == "" || tbMaxLenghtTime.Text == "" || tbMaxHeight.Text == ""
               || tbMaxHeightTime.Text == "" || tbCorrectAngle.Text == "") MessageBox.Show("Введите все данные!");
            else
            {
                double mark = 0;
                if (Convert.ToDouble(tbMaxLenght.Text) == rowLabWork.maxLenghtValue || Convert.ToDouble(tbMaxLenghtTime.Text) == rowLabWork.maxLenghtTimeValue)
                {
                    mark += 0.5;
                    MaxLenght = true;
                }
                if (Convert.ToDouble(tbMaxHeight.Text) == rowLabWork.maxHeightValue || Convert.ToDouble(tbMaxHeightTime.Text) == rowLabWork.maxHeightTimeValue)
                {
                    mark += 0.5;
                    MaxHeight = true;

                }
                if (radioButtonCorrect1.Checked)
                {
                    mark += 0.33;
                    correct1 = true;

                }
                if (radioButtonCorrect2.Checked)
                {
                    mark += 0.33;
                    correct2 = true;

                }
                if (radioButtonCorrect3.Checked)
                {
                    mark += 0.33;
                    correct3 = true;

                }
                if (Convert.ToDecimal(tbCorrectAngle.Text) == rowLabWork.correctAngleValueVar2)
                {
                    mark++;
                    correctAngle = true;
                }
                this.labWorkStudentTableAdapter.Insert(ClassTotal.idUser, labVar, MaxLenght, MaxHeight, correct1, correct2, correct3, correctAngle, Convert.ToInt32(Math.Round(mark + 2, 0)));
                string message = "Завершая лабораторную работу, вы отправляете окончательные варианты ответов. Вы уверены?";
                string caption = "Завершение лабораторной работы";
                var result = MessageBox.Show(message, caption,
                                 MessageBoxButtons.YesNo,
                                 MessageBoxIcon.Question);
                if (result == DialogResult.No)
                {

                }
                else
                {
                    MessageBox.Show("Вы закончили лабораторную работу.\nВаша оценка - " + Math.Round(mark + 2, 0));
                    FormStudent fwwa = new FormStudent();
                    this.Hide();
                    fwwa.ShowDialog();
                    this.Show();
                }
            }
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            FormStudent fwwa = new FormStudent();
            this.Hide();
            fwwa.ShowDialog();
            this.Show();
        }

        private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }
    }
}
 