﻿using Balistics.LogicClass;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Balistics
{
    public partial class FormWorkWithTeacherProfile : Form
    {
        string command;						//С какой целью открывается форма
        //По таблице Users
        SharovBallisticsDataSet.UserLoginDataTable dataUsers;		//все данные
        SharovBallisticsDataSet.UserLoginRow rowUser;			//Отдельная строка таблицы
        //Данные по таблице Spоnsors для редактирования
        SharovBallisticsDataSet.TeacherDataTable dataTeachers;	//все данные
        SharovBallisticsDataSet.TeacherRow rowTeacher;		//Отдельная строка таблицы

        public FormWorkWithTeacherProfile(string command)
        {
            InitializeComponent();
            this.command = command;			//Получение цели, с какой создается форма
        }


        /// <summary>
        /// Отображение формы профиля
        /// </summary>
        private void FormWorkWithTeacherProfile_Load(object sender, EventArgs e)
        {
            //Начальные настройки интерфейса
            buttonAddProfile.Visible = false;
            buttonEditProfile.Visible = false;
            buttonBack.Enabled = true;
            //Данные из таблицы Users, которые нельзя менять
            dataUsers = this.userLoginTableAdapter.GetData();
            rowUser = dataUsers.FindByid(ClassTotal.idUser);
            labelID.Text = "Ваш номер: " + rowUser.id.ToString();
            labelLog.Text = "Ваш логин: " + rowUser.Email;
            labelPas.Text = "Ваш пароль: " + rowUser.Password;
            switch (command)
            {
                case "Addition":
                    buttonAddProfile.Visible = true;
                    buttonBack.Enabled = false;
                    break;
                case "ViewEdit":
                    buttonEditProfile.Visible = true;
                    dataTeachers = this.teacherTableAdapter.GetData();	//Все данные из Sponsors
                    //Поиск среди них запись с нужным ID
                    rowTeacher = dataTeachers.FindByidTeacher(ClassTotal.idUser);
                    //Перенос данных из записи в элементы интерфейса
                    textBoxFirstName.Text = rowTeacher.FirstName;
                    textBoxLastName.Text = rowTeacher.LastName;
                    textBoxMiddleName.Text = rowTeacher.MiddleName;


                    break;
            }

        }

        /// <summary>
        /// Возврат на форму спонсора
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void buttonBack_Click(object sender, EventArgs e)
        {
            FormTeacher fwwa = new FormTeacher();
            this.Hide();
            fwwa.ShowDialog();
            this.Show();
        }

        private void buttonAddProfile_Click(object sender, EventArgs e)
        {
            string FirstName = textBoxFirstName.Text;
            if (FirstName == "")
            {
                MessageBox.Show("Не заполнили имя или фамилию");
                return;
            }
            string LastName = textBoxLastName.Text;
            if (LastName == "")
            {
                MessageBox.Show("Не заполнили имя или фамилию");
                return;
            }
            string MiddleName = textBoxMiddleName.Text;
            if (MiddleName == "")
            {
                MessageBox.Show("Не заполнили имя или фамилию");
                return;
            }
            try
            {
                this.teacherTableAdapter.Insert(ClassTotal.idUser, LastName, FirstName, MiddleName);
                MessageBox.Show("Ваш профиль добавлен в систему");
                buttonAddProfile.Visible = false;
                buttonBack.Enabled = true;		//доступ к функционалу спонсора
            }
            catch
            {
                MessageBox.Show("Ошибка при добавлении профиля");
            }
        }

        private void buttonEditProfile_Click(object sender, EventArgs e)
        {
            //Заполнить строку-шаблон данными из элементов формы
            string sponsorName = textBoxFirstName.Text;
            if (sponsorName == "")
            {
                MessageBox.Show("Не заполнили имя или фамилию");
                return;
            }
            string sponsorName1 = textBoxLastName.Text;
            if (sponsorName1 == "")
            {
                MessageBox.Show("Не заполнили имя или фамилию");
                return;
            }
            string sponsorName2 = textBoxMiddleName.Text;
            if (sponsorName2 == "")
            {
                MessageBox.Show("Не заполнили имя или фамилию");
                return;
            }
            rowTeacher.FirstName = textBoxFirstName.Text;
            rowTeacher.LastName = textBoxLastName.Text;
            rowTeacher.MiddleName = textBoxMiddleName.Text;
            try
            {
                this.teacherTableAdapter.Update(rowTeacher);
                MessageBox.Show("Ваш профиль обновлен в системе");
                buttonBack.Enabled = true;		//доступ к функционалу спонсора
            }
            catch
            {
                MessageBox.Show("Ошибка при обновлении профиля");
            }
        }

        private void FormWorkWithTeacherProfile_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }
    }
}
