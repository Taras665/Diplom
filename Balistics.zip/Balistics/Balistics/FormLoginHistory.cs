﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Balistics
{
    public partial class FormLoginHistory : Form
    {
        public FormLoginHistory()
        {
            InitializeComponent();
        }

        int BedLogin = 0;

        SharovBallisticsDataSet.LogHistoryDataTable dataLoginHistory;


        string inputtype;
        private void FormLoginHistory_Load(object sender, EventArgs e)
        {
            //Получение данных из нужной таблицы БД с помощью адаптера
            dataLoginHistory = this.logHistoryTableAdapter.GetData();
            //Получить количество записей

            for (int i = 1; i <= dataGridView1.RowCount; i++)
            {
                if ((bool)dataGridView1.Rows[i].Cells[1].Value == false)
                    BedLogin++;
            }
            this.label5.Text = "Количество неудачных входов = " + BedLogin.ToString();
            //Отображение в сетке
            this.dataGridView1.DataSource = dataLoginHistory;
            //Настройка сетки
            this.dataGridView1.Columns["Login"].HeaderText = "Login";
            this.dataGridView1.Columns["TimeLogin"].HeaderText = "TimeLogin";
            this.dataGridView1.Columns["ResultLogin"].HeaderText = "ResultLogin";
            this.dataGridView1.Columns["ID"].Visible = false;
            this.dataGridView1.RowHeadersVisible = false;

            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AutoSizeColumnsMode =
            DataGridViewAutoSizeColumnsMode.Fill;
        }

        private void buttonExit_Click(object sender, EventArgs e)
        {
            FormAdmin fwwa = new FormAdmin();
            this.Hide();
            fwwa.ShowDialog();
            this.Show();
        }

        private void FormLoginHistory_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }
        
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            inputtype = (string)comboBox1.Text;
            switch (inputtype)
            {
                case "All":
                    inputtype = null;
                    (dataGridView1.DataSource as DataTable).DefaultView.RowFilter = String.Format("ResultLogin = false or ResultLogin = true", inputtype);
                    break;
                case "Successful":
                    inputtype = "true";
                    (dataGridView1.DataSource as DataTable).DefaultView.RowFilter = String.Format("ResultLogin = true", inputtype);
                    break;
                case "Unsuccessful":
                    inputtype = "false";
                    (dataGridView1.DataSource as DataTable).DefaultView.RowFilter = String.Format("ResultLogin = false", inputtype);
                    break;
            }
        }

        private void tbSearchLogin_TextChanged(object sender, EventArgs e)
        {
            (dataGridView1.DataSource as DataTable).DefaultView.RowFilter = String.Format("Login like '%{0}%'", tbSearchLogin.Text);
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
