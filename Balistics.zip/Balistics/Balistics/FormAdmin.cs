﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Balistics
{
    public partial class FormAdmin : Form
    {
        public FormAdmin()
        {
            InitializeComponent();
        }

        private void buttonLoginHistory_Click(object sender, EventArgs e)
        {
            FormLoginHistory flh = new FormLoginHistory();
            this.Hide();
            flh.ShowDialog();
            this.Show();
        }

        private void FormAdmin_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void buttonBack_Click(object sender, EventArgs e)
        {
            FormAuth fwwa = new FormAuth();
            this.Hide();
            fwwa.ShowDialog();
            this.Show();
        }

        private void buttonWorkWithAccoounts_Click(object sender, EventArgs e)
        {
            FormWorkWithAccount fwwa = new FormWorkWithAccount();
            this.Hide();
            fwwa.ShowDialog();
            this.Show();
        }

        private void FormAdmin_Load(object sender, EventArgs e)
        {

        }
    }
}
