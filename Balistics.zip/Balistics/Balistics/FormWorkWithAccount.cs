﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Balistics
{
    public partial class FormWorkWithAccount : Form
    {
        public FormWorkWithAccount()
        {
            InitializeComponent();
        }
        SharovBallisticsDataSet.UserLoginDataTable dataUsers;   //Данные из таблицы пользователей

        /// Подготовка к регистрации нового пользователя в системе
        private void buttonRegistration_Click(object sender, EventArgs e)
        {
            this.textBoxLog.Enabled = true;		//Доступно для изменения
            this.textBoxPas.Enabled = true;
            this.comboBoxRole.Enabled = true;
            this.buttonInsert.Enabled = true;
            textBoxLog.Text = "";
            textBoxPas.Text = "";
            this.buttonInsert.Enabled = true;		//Разблокировано внесение изменений
        }

        /// Добавить нового пользователя в систему
        private void buttonInsert_Click(object sender, EventArgs e)
        {
            string log = textBoxLog.Text;
            string pas = textBoxPas.Text;
            //Контроль корректности заполнения полей
            if (String.IsNullOrEmpty(log) || String.IsNullOrEmpty(pas))
            {
                MessageBox.Show("Не все поля заполнены");
                return;
            }
            int pos = log.IndexOf('@');
            if (pos < 0)
            {
                MessageBox.Show("В логине отсутствуют обязательный символ @");
                return;
            }
            pos = log.IndexOf('.');
            if (pos < 0)
            {
                MessageBox.Show("В логине отсутствуют обязательный символ .");
                return;
            }
            if ((int)comboBoxRole.SelectedValue == 1)
            {
                MessageBox.Show("Нельзя добавлять нового организатора."
                    + Environment.NewLine + "Выберите другою роль");
                return;
            }

            if (pas.Length < 6) //проверка длины пароля
            {
                MessageBox.Show("Пароль слишком короткий");
                return;
            }
            if (pas.Contains('1') || pas.Contains('2') || pas.Contains('3') || pas.Contains('4') || pas.Contains('5') ||
                pas.Contains('6') || pas.Contains('7') || pas.Contains('8') || pas.Contains('9') || pas.Contains('0')) //проверка длины пароля
            { }
            else
            {
                MessageBox.Show("Пароль должен содержать цифры");
                return;
            }


            //Поиск совпадений по данным
            var filter = dataUsers.Where(rec => rec.Email == log);
            if (filter.Count() == 0)	//Нет записей – совпадение логина+пароля не найдено
            {
                try
                {
                    usersTableAdapter.Insert(log, pas, (int)comboBoxRole.SelectedValue);
                    MessageBox.Show("Данные о новом пользователе успешно сохранены в БД");
                    FormWorkWithAccount_Load(null, null);		//Обновить данные в таблице
                }
                catch
                {
                    MessageBox.Show("При добавлении нового пользователя возникли проблемы");
                    return;
                }
            }
            else				//Данные в БД есть
            {
                MessageBox.Show("Такой пользователь уже зарегистрирован в системе." +
                                                    Environment.NewLine + " Введите другие данные");
                return;
            }
        }

        /// При открытии формы отобразить всех бегунов и спонсоров
        private void FormWorkWithAccount_Load(object sender, EventArgs e)
        {
            //Получение всех записей из таблицы Users
            dataUsers = this.usersTableAdapter.GetData();
            //Отбор только с ролью бегун (3) и спонсор (2)
            var filter = dataUsers.Where(rec => rec.IdRole == 3 || rec.IdRole == 2);
            //Количество записей
            int totalCount = filter.Count();
            //Отобразить полученные записи в компоненте
            this.dataGridViewAcc.DataSource = filter.CopyToDataTable();
            //Выделять всю строку
            this.dataGridViewAcc.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewAcc.Select();		//Выбрать первую строку
            //Настроить список ролей в ComboBox
            this.comboBoxRole.DataSource = this.rolesTableAdapter.GetData();
            this.comboBoxRole.DisplayMember = "Title";	//Видеть
            this.comboBoxRole.ValueMember = "ID";		//Получить
            this.textBoxLog.Enabled = false;		//Недоступно для изменения
            this.textBoxPas.Enabled = false;
            this.comboBoxRole.Enabled = false;
            this.buttonInsert.Enabled = false;          //Заблокировано внесение изменений
            this.dataGridViewAcc.AllowUserToAddRows = false;
            this.dataGridViewAcc.RowHeadersVisible = false;

        }

        /// Перемещение активности по строкам таблицы и отображение в полях панели
        private void dataGridViewAcc_RowEnter(object sender, DataGridViewCellEventArgs e)
        {
            int numRow = e.RowIndex;				//Получить номер выбранной строки
            //Отобразить в контейнере значения нужных полей
            textBoxLog.Text = dataGridViewAcc.Rows[numRow].Cells[1].Value.ToString();
            textBoxPas.Text = dataGridViewAcc.Rows[numRow].Cells[2].Value.ToString();
            //Отобразить название роли по ее номеру
            comboBoxRole.SelectedValue = (int)dataGridViewAcc.Rows[numRow].Cells[3].Value;
        }

        private void buttonBack_Click(object sender, EventArgs e)
        {
            FormAdmin fwwa = new FormAdmin();
            this.Hide();
            fwwa.ShowDialog();
            this.Show();
        }

        // запрет на ввод символов кроме латиницы и цифр
        private void textBoxPas_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((e.KeyChar >= 'A' && e.KeyChar <= 'Z') || (e.KeyChar >= 'a' && e.KeyChar <= 'z') || (e.KeyChar >= '0' && e.KeyChar <= '9') || e.KeyChar == (char)Keys.Back)
            { }
            else
                e.Handled = true;
        }

        private void FormWorkWithAccount_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

    }
}
