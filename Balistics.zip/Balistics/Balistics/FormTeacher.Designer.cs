﻿namespace Balistics
{
    partial class FormTeacher
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonCheckLab = new System.Windows.Forms.Button();
            this.buttonWorkWithProfile = new System.Windows.Forms.Button();
            this.buttonBack = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();

            this.teacherTableAdapter = new Balistics.SharovBallisticsDataSetTableAdapters.TeacherTableAdapter();

            this.SuspendLayout();
            // 
            // buttonCheckLab
            // 
            this.buttonCheckLab.Enabled = false;
            this.buttonCheckLab.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonCheckLab.Location = new System.Drawing.Point(31, 119);
            this.buttonCheckLab.Name = "buttonCheckLab";
            this.buttonCheckLab.Size = new System.Drawing.Size(248, 47);
            this.buttonCheckLab.TabIndex = 10;
            this.buttonCheckLab.Text = "Просмотр результатов работ";
            this.buttonCheckLab.UseCompatibleTextRendering = true;
            this.buttonCheckLab.UseVisualStyleBackColor = true;
            this.buttonCheckLab.Click += new System.EventHandler(this.buttonCheckLab_Click);
            // 
            // buttonWorkWithProfile
            // 
            this.buttonWorkWithProfile.Enabled = false;
            this.buttonWorkWithProfile.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonWorkWithProfile.Location = new System.Drawing.Point(31, 66);
            this.buttonWorkWithProfile.Name = "buttonWorkWithProfile";
            this.buttonWorkWithProfile.Size = new System.Drawing.Size(248, 47);
            this.buttonWorkWithProfile.TabIndex = 9;
            this.buttonWorkWithProfile.Text = "Работа с профилем";
            this.buttonWorkWithProfile.UseCompatibleTextRendering = true;
            this.buttonWorkWithProfile.UseVisualStyleBackColor = true;
            this.buttonWorkWithProfile.Click += new System.EventHandler(this.buttonWorkWithProfile_Click);
            // 
            // buttonBack
            // 
            this.buttonBack.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonBack.Location = new System.Drawing.Point(31, 172);
            this.buttonBack.Name = "buttonBack";
            this.buttonBack.Size = new System.Drawing.Size(248, 47);
            this.buttonBack.TabIndex = 8;
            this.buttonBack.Text = "Назад";
            this.buttonBack.UseCompatibleTextRendering = true;
            this.buttonBack.UseVisualStyleBackColor = true;
            this.buttonBack.Click += new System.EventHandler(this.buttonBack_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Comic Sans MS", 15.75F, System.Drawing.FontStyle.Bold);
            this.label2.Location = new System.Drawing.Point(73, 20);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(174, 30);
            this.label2.TabIndex = 7;
            this.label2.Text = "Преподаватель";
            // 
            // FormTeacher
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(314, 244);
            this.Controls.Add(this.buttonCheckLab);
            this.Controls.Add(this.buttonWorkWithProfile);
            this.Controls.Add(this.buttonBack);
            this.Controls.Add(this.label2);
            this.Name = "FormTeacher";
            this.Text = "FormTeacher";
            this.Load += new System.EventHandler(this.FormTeacher_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private SharovBallisticsDataSetTableAdapters.TeacherTableAdapter teacherTableAdapter;
        private System.Windows.Forms.Button buttonCheckLab;
        private System.Windows.Forms.Button buttonWorkWithProfile;
        private System.Windows.Forms.Button buttonBack;
        private System.Windows.Forms.Label label2;
    }
}