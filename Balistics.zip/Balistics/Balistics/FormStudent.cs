﻿using Balistics.LogicClass;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Balistics
{
    public partial class FormStudent : Form
    {
        public FormStudent()
        {
            InitializeComponent();
        }

        //Глобальные величины для доступа в данным таблицы Runners
        SharovBallisticsDataSet.StudentDataTable dataStudent;   //Все записи
        SharovBallisticsDataSet.StudentRow rowStudent;		//Отдельная строка

        private void buttonRegistration_Click(object sender, EventArgs e)
        {
            MainForm main = new MainForm(false);
            this.Hide();
            main.ShowDialog();
            this.Show();
        }

        private void buttonMySponsors_Click(object sender, EventArgs e)
        {
            Random random = new Random();
            int labVar = random.Next(1, 7);
            MainForm main = new MainForm(true, labVar);
            this.Hide();
            main.ShowDialog();
            this.Show();
        }




        private void buttonBack_Click(object sender, EventArgs e)
        {
            FormAuth fwwa = new FormAuth();
            this.Hide();
            fwwa.ShowDialog();
            this.Show();
        }

        private void FormRunner_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void buttonWorkWithProfile_Click(object sender, EventArgs e)
        {
            FormWorkWithStudentProfile fwwp = new FormWorkWithStudentProfile("ViewEdit");
            this.Hide();
            fwwp.ShowDialog();
            this.Show();
        }

        //При загрузке формы после успешной авторизации как «Бегун»
        private void FormStudent_Load(object sender, EventArgs e)
        {
            //Получили все данные
            dataStudent = this.studentTableAdapter.GetData();
            //Ищем профиль того аккаунта, который вошел в систему
            rowStudent = dataStudent.FindByidStudent(ClassTotal.idUser);
            if (rowStudent == null)
            {
                MessageBox.Show("У Вас не заполнен профиль."
                    + Environment.NewLine + "Надо его заполнить для дальнейшей работы");
                //Форма профиля
                FormWorkWithStudentProfile frp = new FormWorkWithStudentProfile("Addition");
                this.Hide();
                frp.ShowDialog();
                this.Show();
            }
            else
            {
                MessageBox.Show("У Вас заполнен профиль."
                                    + Environment.NewLine + "Можете работат в системе");
            }
        }

        private void FormStudent_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }
    }
}
