﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Balistics
{
    public partial class FormCheckLab : Form
    {
        public FormCheckLab()
        {
            InitializeComponent();
        }

        int BedLogin = 0;

        SharovBallisticsDataSet.LabWorkStudentDataTable dataLabWorkStudent;

        private void FormCheckLab_Load(object sender, EventArgs e)
        {
            //Получение данных из нужной таблицы БД с помощью адаптера
            dataLabWorkStudent = this.labWorkStudentTableAdapter.GetDataBy();
            //Получить количество записей

            for (int i = 1; i <= dataGridView1.RowCount; i++)
            {
                if ((bool)dataGridView1.Rows[i].Cells[1].Value == false)
                    BedLogin++;
            }
            //Отображение в сетке
            this.dataGridView1.DataSource = dataLabWorkStudent;
            //Настройка сетки
            this.dataGridView1.Columns["LastName"].HeaderText = "Login";
            this.dataGridView1.Columns["LastName"].HeaderText = "TimeLogin";
            this.dataGridView1.Columns["Grade"].HeaderText = "ResultLogin";
            this.dataGridView1.Columns["IdLab"].HeaderText = "Login";
            this.dataGridView1.Columns["maxLenght"].HeaderText = "TimeLogin";
            this.dataGridView1.Columns["maxHeight"].HeaderText = "ResultLogin";
            this.dataGridView1.Columns["correctWeight"].HeaderText = "Login";
            this.dataGridView1.Columns["correctCaliber"].HeaderText = "TimeLogin";
            this.dataGridView1.Columns["correctCRF"].HeaderText = "ResultLogin";
            this.dataGridView1.Columns["correctTarget"].HeaderText = "correctWeight";
            this.dataGridView1.Columns["markStudent"].HeaderText = "markStudent";
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AutoSizeColumnsMode =
            DataGridViewAutoSizeColumnsMode.Fill;
        }
    }
}
