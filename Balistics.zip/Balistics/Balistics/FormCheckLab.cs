﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Balistics
{
    public partial class FormCheckLab : Form
    {
        public FormCheckLab()
        {
            InitializeComponent();
        }

        int BedLogin = 0;

        SharovBallisticsDataSet.LabWorkStudentDataTable dataLabWorkStudent;

        private void FormCheckLab_Load(object sender, EventArgs e)
        {
            //Получение данных из нужной таблицы БД с помощью адаптера
            dataLabWorkStudent = this.labWorkStudentTableAdapter.GetDataBy();
            //Получить количество записей

            for (int i = 1; i <= dataGridView1.RowCount; i++)
            {
                if ((bool)dataGridView1.Rows[i].Cells[1].Value == false)
                    BedLogin++;
            }
            //Отображение в сетке
            this.dataGridView1.DataSource = dataLabWorkStudent;
            //Настройка сетки
            this.dataGridView1.Columns["LastName"].HeaderText = "Фамилия";
            this.dataGridView1.Columns["FirstName"].HeaderText = "Имя";
            this.dataGridView1.Columns["Grade"].HeaderText = "Класс";
            this.dataGridView1.Columns["IdLab"].HeaderText = "Вариант";
            this.dataGridView1.Columns["maxLenght"].HeaderText = "1.1";
            this.dataGridView1.Columns["maxHeight"].HeaderText = "1.2";
            this.dataGridView1.Columns["correctWeight"].HeaderText = "2.1";
            this.dataGridView1.Columns["correctCaliber"].HeaderText = "2.2";
            this.dataGridView1.Columns["correctCRF"].HeaderText = "2.3";
            this.dataGridView1.Columns["correctTarget"].HeaderText = "3.1";
            this.dataGridView1.Columns["markStudent"].HeaderText = "Оценка";

            this.dataGridView1.Columns["LastName"].DisplayIndex = 0;
            this.dataGridView1.Columns["FirstName"].DisplayIndex = 1;
            this.dataGridView1.Columns["Grade"].DisplayIndex = 2;
            this.dataGridView1.Columns["IdLab"].DisplayIndex = 3;
            this.dataGridView1.Columns["maxLenght"].DisplayIndex = 4;
            this.dataGridView1.Columns["maxHeight"].DisplayIndex = 5;
            this.dataGridView1.Columns["correctWeight"].DisplayIndex = 6;
            this.dataGridView1.Columns["correctCaliber"].DisplayIndex = 7;
            this.dataGridView1.Columns["correctCRF"].DisplayIndex = 8;
            this.dataGridView1.Columns["correctTarget"].DisplayIndex = 9;
            this.dataGridView1.Columns["markStudent"].DisplayIndex = 10;

            this.dataGridView1.RowHeadersVisible = false;
            this.dataGridView1.Columns["Id"].Visible = false;
            this.dataGridView1.Columns["IdStudent"].Visible = false;
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AutoSizeColumnsMode =
            DataGridViewAutoSizeColumnsMode.Fill;
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
        string inputtype;
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            inputtype = (string)comboBox1.Text;
            switch (inputtype)
            {
                case "5":
                    inputtype = null;
                    (dataGridView1.DataSource as DataTable).DefaultView.RowFilter = String.Format("markStudent = 5", inputtype);
                    break;
                case "4":
                    inputtype = "true";
                    (dataGridView1.DataSource as DataTable).DefaultView.RowFilter = String.Format("markStudent = 4", inputtype);
                    break;
                case "3":
                    inputtype = "false";
                    (dataGridView1.DataSource as DataTable).DefaultView.RowFilter = String.Format("markStudent = 3", inputtype);
                    break;
                case "2":
                    inputtype = "true";
                    (dataGridView1.DataSource as DataTable).DefaultView.RowFilter = String.Format("markStudent = 2", inputtype);
                    break;
                case "Любая":
                    inputtype = "false";
                    (dataGridView1.DataSource as DataTable).DefaultView.RowFilter = String.Format("markStudent = 5 or markStudent = 4 or markStudent = 3 or markStudent = 2", inputtype);
                    break;
            }
        }

        private void tbSearchLogin_TextChanged(object sender, EventArgs e)
        {
            (dataGridView1.DataSource as DataTable).DefaultView.RowFilter = String.Format("Grade like '%{0}%'", tbSearchLogin.Text);
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void FormCheckLab_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }
    }
}
