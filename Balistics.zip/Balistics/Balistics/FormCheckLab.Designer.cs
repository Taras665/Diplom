﻿namespace Balistics
{
    partial class FormCheckLab
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonExit = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.tbSearchLogin = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.labWorkStudentTableAdapter = new Balistics.SharovBallisticsDataSetTableAdapters.LabWorkStudentTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // buttonExit
            // 
            this.buttonExit.Font = new System.Drawing.Font("Comic Sans MS", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.buttonExit.Location = new System.Drawing.Point(422, 9);
            this.buttonExit.Name = "buttonExit";
            this.buttonExit.Size = new System.Drawing.Size(186, 36);
            this.buttonExit.TabIndex = 28;
            this.buttonExit.Text = "К форме админа";
            this.buttonExit.UseVisualStyleBackColor = true;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(12, 80);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(596, 233);
            this.dataGridView1.TabIndex = 26;
            // 
            // tbSearchLogin
            // 
            this.tbSearchLogin.Location = new System.Drawing.Point(394, 51);
            this.tbSearchLogin.Name = "tbSearchLogin";
            this.tbSearchLogin.Size = new System.Drawing.Size(214, 20);
            this.tbSearchLogin.TabIndex = 25;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.Location = new System.Drawing.Point(260, 51);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(128, 18);
            this.label3.TabIndex = 24;
            this.label3.Text = "Поиск по логину:";
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(117, 51);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 21);
            this.comboBox1.TabIndex = 23;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label4.Location = new System.Drawing.Point(9, 51);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(102, 18);
            this.label4.TabIndex = 22;
            this.label4.Text = "Типы входов:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Comic Sans MS", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(169, 11);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(208, 30);
            this.label1.TabIndex = 20;
            this.label1.Text = "Форма результатов";
            // 
            // FormCheckLab
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(620, 325);
            this.Controls.Add(this.buttonExit);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.tbSearchLogin);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label1);
            this.Name = "FormCheckLab";
            this.Text = "FormCheckLab";
            this.Load += new System.EventHandler(this.FormCheckLab_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonExit;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.TextBox tbSearchLogin;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label1;
        private SharovBallisticsDataSetTableAdapters.UserLoginTableAdapter userLoginTableAdapter;
        private SharovBallisticsDataSetTableAdapters.LogHistoryTableAdapter logHistoryTableAdapter;
        private SharovBallisticsDataSetTableAdapters.TeacherTableAdapter teacherTableAdapter;
        private SharovBallisticsDataSetTableAdapters.RoleTableAdapter roleTableAdapter;
        private SharovBallisticsDataSetTableAdapters.StudentTableAdapter studentTableAdapter;
        private SharovBallisticsDataSetTableAdapters.LabWorkTableAdapter labWorkTableAdapter;
        private SharovBallisticsDataSetTableAdapters.LabWorkStudentTableAdapter labWorkStudentTableAdapter;
        //this.userLoginTableAdapter = new Balistics.SharovBallisticsDataSetTableAdapters.UserLoginTableAdapter();
        //this.logHistoryTableAdapter = new Balistics.SharovBallisticsDataSetTableAdapters.LogHistoryTableAdapter();
        //this.teacherTableAdapter = new Balistics.SharovBallisticsDataSetTableAdapters.TeacherTableAdapter();
        //this.roleTableAdapter = new Balistics.SharovBallisticsDataSetTableAdapters.RoleTableAdapter();
        //this.studentTableAdapter = new Balistics.SharovBallisticsDataSetTableAdapters.StudentTableAdapter();
        //this.labWorkTableAdapter = new Balistics.SharovBallisticsDataSetTableAdapters.LabWorkTableAdapter();
        //this.labWorkStudentTableAdapter = new Balistics.SharovBallisticsDataSetTableAdapters.LabWorkStudentTableAdapter();
    }
}