﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Balistics.LogicClass
{
    internal class ClassTotal
    {
        public static int idRole, idUser;
        public static string login;
    }
}
