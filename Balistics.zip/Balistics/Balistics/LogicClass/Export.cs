﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using Excel = Microsoft.Office.Interop.Excel;

namespace Balistics.LogicClass
{
    internal class Export
    {
        public double time;
        public double x;
        public double y;
        public DataSet bookStore = new DataSet("BookStore");
        public DataTable booksTable = new DataTable("Books");
        public Export()
        {
            bookStore.Tables.Add(booksTable);
            DataColumn TimeColumn = new DataColumn("Время (с)", Type.GetType("System.Double"));
            DataColumn xColumn = new DataColumn("Длина (м)", Type.GetType("System.Double"));
            DataColumn yColumn = new DataColumn("Высота (м)", Type.GetType("System.Double"));
            booksTable.Columns.Add(TimeColumn);
            booksTable.Columns.Add(xColumn);
            booksTable.Columns.Add(yColumn);
        }
        public void AddRow(double time, double x, double y)
        {
            booksTable.Rows.Add(new object[] { Math.Round(time, 1), Math.Round(x, 2), Math.Round(y, 2)});
        }

        public void Clear()
        { 
            booksTable.Rows.Clear(); 
        }
        public string CreateFile()
        {
            string s = "";
            if (booksTable.Rows.Count == 0)
            {
                return "";
            }
            else
            {
                Excel.Application ex = new Excel.Application();
                ex.SheetsInNewWorkbook = 1;
                Excel.Workbook workBook = ex.Workbooks.Add(Type.Missing);
                Excel.Worksheet sheet = (Excel.Worksheet)ex.Worksheets.get_Item(1);
                ex.DisplayAlerts = true;
                sheet.Name = "Расчёт";
                sheet.Cells[1, 1] = String.Format("Длина ствола (м)");
                sheet.Cells[1, 2] = String.Format("Высота ствола (м)");
                sheet.Cells[1, 3] = String.Format("Угол");
                sheet.Cells[1, 4] = String.Format("Скорость снаряда (м/с)");
                sheet.Cells[1, 5] = String.Format("Радиус поражения (м)");
                sheet.Cells[1, 6] = String.Format("Расстояние до цели (м)");
                sheet.Cells[1, 7] = String.Format("Коэффицент сопротивления формы");
                sheet.Cells[1, 8] = String.Format("Калибр (м)");
                sheet.Cells[1, 9] = String.Format("Масса (кг)");

                sheet.Cells[2, 1] = String.Format(Program.logic.lenght.ToString());
                sheet.Cells[2, 2] = String.Format(Program.logic.height.ToString());
                sheet.Cells[2, 3] = String.Format(Program.logic.degreeAngle.ToString());
                sheet.Cells[2, 4] = String.Format(Program.logic.speedBulletInitial.ToString());
                sheet.Cells[2, 5] = String.Format(Program.logic.damage.ToString());
                sheet.Cells[2, 6] = String.Format(Program.logic.target.ToString());
                sheet.Cells[2, 7] = String.Format(Program.logic.CRF.ToString());
                sheet.Cells[2, 8] = String.Format(Program.logic.diametrBullet.ToString());
                sheet.Cells[2, 9] = String.Format(Program.logic.weightBullet.ToString());

                sheet.Cells[4, 1] = String.Format(booksTable.Columns[0].ColumnName);
                sheet.Cells[4, 2] = String.Format(booksTable.Columns[1].ColumnName);
                sheet.Cells[4, 3] = String.Format(booksTable.Columns[2].ColumnName);

                for (int i = 0; i < booksTable.Rows.Count; i++)
                {
                    sheet.Cells[i + 5, 1] = String.Format(booksTable.Rows[i][0].ToString());
                    sheet.Cells[i + 5, 2] = String.Format(booksTable.Rows[i][1].ToString());
                    sheet.Cells[i + 5, 3] = String.Format(booksTable.Rows[i][2].ToString());
                }
                string namefile = String.Format("Расчёты_{0}_{1}.{2}.{3}.xlsx", DateTime.Now.ToShortDateString(), DateTime.Now.Hour, DateTime.Now.Minute, DateTime.Now.Second);
                ex.Application.ActiveWorkbook.SaveAs(namefile, Type.Missing,
                Type.Missing, Type.Missing, Type.Missing, Type.Missing, Excel.XlSaveAsAccessMode.xlNoChange,
                Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);

                ex.Application.Quit();
                Marshal.ReleaseComObject(sheet);
                Marshal.ReleaseComObject(workBook);
                Marshal.ReleaseComObject(ex);
                return "";

            }
        }
    }
}
