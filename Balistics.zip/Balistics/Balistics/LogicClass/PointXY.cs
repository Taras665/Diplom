﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Balistics.LogicClass
{
    /// <summary>
    /// 
    /// </summary>
    internal class PointXY
    {
        public double x;
        public double y;
        public double time;

        public void Clear()
        {
            x = 0;
            y = 0;
            time = 0;
        }

    }
}
