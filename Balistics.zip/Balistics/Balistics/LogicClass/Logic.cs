﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Balistics.LogicClass
{
    internal class Logic
    {
        public double lenght;
        public double height;
        public double degreeAngle;

        private double x0;
        private double radianAngle;
        private double y0;
        private double g = 9.81;
        public double max;
        public double target;
        public double damage;

        public double x;
        public double y;
        public double time;

        private double airForce;



        public double speedBulletInitial;
        private double speedBulletX;
        private double speedBulletY;

        public double weightBullet;
        public bool airEnable;


        public double diametrBullet;
        private double areaBullet;
        private double airDestiny = 1.2754;
        public double CRF;

        public static Result[] results =
        {
            new Result("Цель поражена!", Color.Green),
            new Result("Промах", Color.Red)
        };

        PointXY point = new PointXY();
        /// <summary>
        /// 
        /// </summary>
        /// <param name="lenghtImport"> </param>
        /// <param name="heightImport"> </param>
        /// <param name="angleImport"> </param>
        /// <param name="speedBulletInitialImport"> </param>
        /// <param name="targetImport"> </param>
        /// <param name="damageImport"> </param>
        /// <param name="diametrBulletImport"> </param>
        /// <param name="CRFImport"> </param>
        /// <param name="weightBulletImport"> </param>
        public void Update(double lenghtImport, double heightImport, double angleImport, double speedBulletInitialImport, double targetImport, double damageImport, bool airEnableImport, double diametrBulletImport = 0, double CRFImport = 0, double weightBulletImport = 1)
        {
            lenght = lenghtImport;
            height = heightImport;
            degreeAngle = angleImport;
            speedBulletInitial = speedBulletInitialImport;
            target = targetImport;
            damage = damageImport;
            diametrBullet = diametrBulletImport;
            CRF = CRFImport;
            weightBullet = weightBulletImport;
            airEnable = airEnableImport;
            x0 = 0;
            radianAngle = degreeAngle * Math.PI / 180;
            y0 = height + lenght * Math.Sin(radianAngle);
            y = height + lenght * Math.Sin(radianAngle);
            x = 0;
            time = 0.1;
            max = 0;
            Program.export.Clear();
            Program.export.AddRow(0, x0, y0);


            areaBullet = Math.PI * Math.Pow(diametrBullet, 2) / 4;
            speedBulletX = speedBulletInitial * Math.Cos(radianAngle);
            speedBulletY = speedBulletInitial * Math.Sin(radianAngle);

            airForce = (airDestiny * areaBullet / 2 * CRF)/ weightBullet;

            point.Clear();
        }

        public PointXY AddPoint()
        {
            point.time += time;
            if (airEnable)
            {
                point.x = (speedBulletX / (airForce * g)) * (1 - Math.Pow(Math.E, -airForce * g * point.time));
                point.y = (1 / (airForce * g) * ((1 / airForce) + speedBulletY) * (1 - Math.Pow(Math.E, -airForce * g * point.time))) - (point.time / airForce);
            }
            else
            {
                point.x = x0 + (speedBulletX * point.time);
                point.y = y0 + (speedBulletY * point.time) - (g  * Math.Pow(point.time, 2) / 2);
            }
            Max(point.y);
            Program.export.AddRow(point.time,point.x,point.y);
            return point;
        }
        /// <summary>
        ///     
        /// </summary>
        /// <param name="y"></param>
        public void Max(double y)
        {
            if (y > max)
                max = y;
        }

        public Result GetResult()
        {
            if (target >= (point.x - damage) && target <= (point.x + damage))  return results[0];
            else return results[1];
        }

    }
    class Result
    {
        public string textResult;
        public Color color;
        public Result(string text, Color colorImport)
        {
            textResult = text;
            color = colorImport;
        }

    }
}
