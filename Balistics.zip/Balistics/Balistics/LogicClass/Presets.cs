﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Balistics.LogicClass
{
    internal class Presets
    {
        public string name;
        public string lenght;
        public string height;
        public string maxDegreeAngle;
        public string speedBulletInitial;
        public string target;
        public string damage;
        public string weightBullet;
        public string diametrBullet;
        public string CRF;
        public Presets(string lenghtImport = "", string heightImport = "", string maxDegreeAngleImport = "", string speedBulletInitialImport = "", string targetImport = "", string damageImport = "",
            string weightBulletImport = "", string diametrBulletImport = "", string CRFImport = "", string nameImport = "")
        {

            lenght = lenghtImport;
            height = heightImport;
            maxDegreeAngle = maxDegreeAngleImport;
            speedBulletInitial = speedBulletInitialImport;
            target = targetImport;
            damage = damageImport;
            weightBullet = weightBulletImport;
            diametrBullet = diametrBulletImport;
            CRF = CRFImport;
            name = nameImport;
        }

        public static Presets[] Preset =
        {
            new Presets("0","0","0","0","0","0","0","0","0","Свой"),
            new Presets("2,331","0,280","5","260","0","0,1","0,732","0,037","0,07","ЧК-М1"),
            new Presets("6,126","1,250","20","300","0","0,5","20","0,1","0,04","МТ-12 Рапира"), 
            new Presets("4,24","2,270","65","405","0","1","40","0,152","0,08","МЛ-20")

        };
        public int GetID(string name)
        {
            int id = -1;
            for (int i = 0; i < Preset.Length; i++)
            {
                if (Preset[i].name == name)
                    id = i;
            }
            return id;
        }
    }

    
}
