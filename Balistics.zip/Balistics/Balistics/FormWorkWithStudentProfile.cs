﻿using Balistics.LogicClass;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Balistics
{
    public partial class FormWorkWithStudentProfile : Form
    {
        string command;						//С какой целью открывается форма
        //По таблице Users
        SharovBallisticsDataSet.UserLoginDataTable dataUsers;		//все данные
        SharovBallisticsDataSet.UserLoginRow rowUser;			//Отдельная строка таблицы
        //Данные по таблице Spоnsors для редактирования
        SharovBallisticsDataSet.StudentDataTable dataStudents;	//все данные
        SharovBallisticsDataSet.StudentRow rowStudent;		//Отдельная строка таблицы

        public FormWorkWithStudentProfile(string command)
        {
            InitializeComponent();
            this.command = command;			//Получение цели, с какой создается форма
        }


        /// <summary>
        /// Отображение формы профиля
        /// </summary>
        private void FormWorkWithStudentProfile_Load(object sender, EventArgs e)
        {
            //Начальные настройки интерфейса
            buttonAddProfile.Visible = false;
            buttonEditProfile.Visible = false;
            buttonBack.Enabled = true;
            //Данные из таблицы Users, которые нельзя менять
            dataUsers = this.userLoginTableAdapter.GetData();
            rowUser = dataUsers.FindByid(ClassTotal.idUser);
            labelID.Text = "Ваш номер: " + rowUser.id.ToString();
            labelLog.Text = "Ваш логин: " + rowUser.Email;
            labelPas.Text = "Ваш пароль: " + rowUser.Password;
            switch (command)
            {
                case "Addition":
                    buttonAddProfile.Visible = true;
                    buttonBack.Enabled = false;
                    break;
                case "ViewEdit":
                    buttonEditProfile.Visible = true;
                    dataStudents = this.studentTableAdapter.GetData();	//Все данные из Sponsors
                    //Поиск среди них запись с нужным ID
                    rowStudent = dataStudents.FindByidStudent(ClassTotal.idUser);
                    //Перенос данных из записи в элементы интерфейса
                    textBoxFirstName.Text = rowStudent.FirstName;
                    textBoxLastName.Text = rowStudent.LastName;
                    textBoxGrade.Text = rowStudent.Grade;


                    break;
            }

        }

        /// <summary>
        /// Возврат на форму спонсора
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void buttonBack_Click(object sender, EventArgs e)
        {
            FormStudent fwwa = new FormStudent();
            this.Hide();
            fwwa.ShowDialog();
            this.Show();
        }

        private void buttonAddProfile_Click(object sender, EventArgs e)
        {
            string FirstName = textBoxFirstName.Text;
            string LastName = textBoxLastName.Text;
            string MiddleName = textBoxGrade.Text;
            if (FirstName == "" || LastName == "" || MiddleName == "")
            {
                MessageBox.Show("Вы не заполнили все поля");
                return;
            }
            try
            {
                this.studentTableAdapter.Insert(ClassTotal.idUser, LastName, FirstName, MiddleName);
                MessageBox.Show("Ваш профиль добавлен в систему");
                buttonAddProfile.Visible = false;
                buttonBack.Enabled = true;		//доступ к функционалу спонсора
            }
            catch
            {
                MessageBox.Show("Ошибка при добавлении профиля");
            }
        }

        private void buttonEditProfile_Click(object sender, EventArgs e)
        {
            //Заполнить строку-шаблон данными из элементов формы
            string FirstName = textBoxFirstName.Text;
            string LastName = textBoxLastName.Text;
            string MiddleName = textBoxGrade.Text;
            if (FirstName == "" || LastName == "" || MiddleName == "")
            {
                MessageBox.Show("Вы не заполнили все поля");
                return;
            }
            rowStudent.FirstName = textBoxFirstName.Text;
            rowStudent.LastName = textBoxLastName.Text;
            rowStudent.Grade = textBoxGrade.Text;
            try
            {
                this.studentTableAdapter.Update(rowStudent);
                MessageBox.Show("Ваш профиль обновлен в системе");
                buttonBack.Enabled = true;		//доступ к функционалу спонсора
            }
            catch
            {
                MessageBox.Show("Ошибка при обновлении профиля");
            }
        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void FormWorkWithStudentProfile_FormClosing(object sender, FormClosingEventArgs e)
        {

                Application.Exit();

        }
    }
}
